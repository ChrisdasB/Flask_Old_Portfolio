mail_address = "no.reply.csvw@web.de"
mail_password = "Malaka132"
contact_mail = "Chris.Schmidtvw@outlook.com"
